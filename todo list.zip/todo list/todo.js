let button = document.querySelector("button");
let input = document.querySelector("input");
let ul = document.querySelector('ul');
button.addEventListener("click", function () {
    let item = document.createElement("li");
    let delbtn = document.createElement("button");
    item.innerText = input.value;
    delbtn.innerText = "delete";
    delbtn.classList.add("del");
    item.appendChild(delbtn);
    ul.appendChild(item);
    input.value = "";
    /** delbtn.addEventListener("click", function () {
         item.remove();
     });*/
});

// use event delegation for delete the item
ul.addEventListener("click", function (event) {
    //ul element chya event che target chya nodeName jar name  jar button asel tar the tyacha parent delete karaycha
    //checkout in event.target
    if (event.target.nodeName == "BUTTON") {
        let listitem = event.target.parentElement;
        listitem.remove();
    }
});